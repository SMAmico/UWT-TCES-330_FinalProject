//seth amico
//tces330 project
//part: ALU
module ALU(clk, ALUA, ALUB, ALUop, ALUout);
	input [15:0]ALUA, ALUB;			//input lines
	input clk;						//clocksignal
	input [3:0]ALUop;				//alu control lines
	output logic [15:0]ALUout;		//alu output
	
	always @(posedge clk) begin
		case(ALUop)//take instruction bits
			4'h0: ALUout <= ALUA + 0;	//nop
			
			4'h1: ALUout <= ALUA + ALUB; //add
			
			4'h2: ALUout <= ALUA - ALUB; //sub
			
			4'h3: ALUout <= ALUA;		 //passthrough
			
			4'h4: ALUout <= ALUA ^ ALUB; //xor
			
			4'h5: ALUout <= ALUA | ALUB; //or
			
			4'h6: ALUout <= ALUA & ALUB; //and
			
			4'h7: ALUout <= ALUA + 1'b1; //increment
			
		endcase
	end
	
endmodule

module ALU_tb();
	reg [15:0]ALUA, ALUB;			//input lines
	reg clk;						//clocksignal
	reg [3:0]ALUop;				//alu control lines
	logic [15:0]ALUout;		//alu output
	reg [3:0]ALUop_rand;
	reg [15:0]ALUA_rand, ALUB_rand;

	ALU dut(.clk(clk), .ALUA(ALUA), .ALUB(ALUB), .ALUop(ALUop), .ALUout(ALUout));

	

initial begin
//alu tests
	clk <= 0;

	
//test add
	ALUA = 16'd1;
	ALUB = 16'd1;
	ALUop = 4'h1;
	#1;
	clk <= ~clk;
	#1;
	assert(ALUout == 16'd2)
		else $error("ALUout: %b", ALUout);
	clk <= ~clk;

//test sub
	ALUA = 16'd4;
	ALUB = 16'd2;
	ALUop = 4'h2;
	#1;
	clk <= ~clk;
	#1;
	assert(ALUout == 16'd2)
		else $error("ALUout: %b", ALUout);
	clk <= ~clk;

//test passthrough
	ALUA = 16'd512;
	ALUB = 16'd256;
	ALUop = 4'h3;
	#1;
	clk <= ~clk;
	#1;
	assert(ALUout == 16'd512)
		else $error("ALUout: %b", ALUout);
	clk <= ~clk;

//test xor
	ALUA = 16'd0;
	ALUB = 16'd1;
	ALUop = 4'h4;
	#1;
	clk <= ~clk;
	#1;
	assert(ALUout == 16'd1)
		else $error("ALUout: %b", ALUout);
	clk <= ~clk;

//test or
	ALUA = 16'd0;
	ALUB = 16'd1;
	ALUop = 4'h5;
	#1;
	clk <= ~clk;
	#1;
	assert(ALUout == 16'd1)
		else $error("ALUout: %b", ALUout);
	clk <= ~clk;

//test and
	ALUA = 16'd1;
	ALUB = 16'd1;
	ALUop = 4'h6;
	#1;
	clk <= ~clk;
	#1;
	assert(ALUout == 16'd1)
		else $error("ALUout: %b", ALUout);
	clk <= ~clk;

//test increment
	ALUA = 16'd256;
	ALUB = 16'd0;
	ALUop = 4'h7;
	#1;
	clk <= ~clk;
	#1;
	assert(ALUout == 16'd257)
		else $error("ALUout: %b", ALUout);
	clk <= ~clk;

//RAND TEST:input a random instruction and predict its output
//the end result'll probably be just the ALU with asserts in it
	
	for(int i = 0; i < 256; i++) begin
		ALUA_rand = $urandom_range(16'hFFFF,0);
		ALUB_rand = $urandom_range(16'hFFFF,0);
		ALUop_rand = $urandom_range(4'd7,0);
		ALUA = ALUA_rand;
		ALUB = ALUB_rand;
		ALUop = ALUop_rand;
		#1;
		clk <= ~clk;
		#1;
			
			case(ALUop_rand)//take instruction bits
				4'h0: assert(ALUout == ALUA_rand + 0);    //nop
				
				4'h1: assert(ALUout == ALUA_rand + ALUB_rand); //add
				
				4'h2: assert(ALUout == ALUA_rand - ALUB_rand); //sub
				
				4'h3: assert(ALUout == ALUA_rand);		 //passthrough
				
				4'h4: assert(ALUout == (ALUA_rand ^ ALUB_rand)); //xor
				
				4'h5: assert(ALUout == (ALUA_rand | ALUB_rand)); //or
				
				4'h6: assert(ALUout == (ALUA_rand & ALUB_rand)); //and
				
				4'h7: assert(ALUout == ALUA_rand + 1'b1); //increment
			endcase

		clk <= ~clk;
		
	end

end

endmodule