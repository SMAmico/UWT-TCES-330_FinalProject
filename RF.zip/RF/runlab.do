# Create work library
vlib work

# Compile SystemVerilog file
# This file contains both the ALU module and the ALU_tb testbench.
vlog -reportprogress 300 "./regfile8x16a.sv"

# Start simulation using the ALU testbench.
vsim -voptargs="+acc" -t 1ps -lib work regfile8x16a_tb

# Load waveform setup.
do regfile8x16a_wave.do

# Open useful simulation windows.
view wave
view structure
view signals

# Run the full testbench.
run -all